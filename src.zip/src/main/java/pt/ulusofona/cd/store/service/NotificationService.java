package pt.ulusofona.cd.store.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pt.ulusofona.cd.store.events.EventEnvelope;
import pt.ulusofona.cd.store.events.ReservationEventPayload;
import pt.ulusofona.cd.store.events.RestaurantNotifiedProducer;
import pt.ulusofona.cd.store.model.Notification;
import pt.ulusofona.cd.store.model.NotificationStatus;
import pt.ulusofona.cd.store.model.ProcessedEvent;
import pt.ulusofona.cd.store.repository.NotificationRepository;
import pt.ulusofona.cd.store.repository.ProcessedEventRepository;

import java.time.Instant;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final ProcessedEventRepository processedEventRepository;
    private final RestaurantNotifiedProducer producer;

    private final ObjectMapper objectMapper = new ObjectMapper();

    public NotificationService(NotificationRepository notificationRepository,
                               ProcessedEventRepository processedEventRepository,
                               RestaurantNotifiedProducer producer) {
        this.notificationRepository = notificationRepository;
        this.processedEventRepository = processedEventRepository;
        this.producer = producer;
    }

    @Transactional
    public void processReservationEnvelope(EventEnvelope<?> rawEnvelope) {

        // envelope base
        String eventType = rawEnvelope.getEventType();
        String traceId = rawEnvelope.getTraceId();

        // payload -> ReservationEventPayload
        ReservationEventPayload payload = objectMapper.convertValue(rawEnvelope.getPayload(), ReservationEventPayload.class);

        Long reservationId = payload.getReservationId();
        if (reservationId == null) {
            throw new IllegalArgumentException("reservationId is required in payload");
        }

        // IDMP KEY = (reservationId + eventType)
        boolean alreadyProcessed = processedEventRepository.existsByReservationIdAndEventType(reservationId, eventType);
        if (alreadyProcessed) {
            return; // skip (ack vai acontecer no consumer)
        }

        // “enviar” notificação (mock): escolhe recipient (por simplicidade: customerEmail)
        String recipient = payload.getCustomerEmail();

        // tentar enviar (aqui é mock)
        NotificationStatus status = NotificationStatus.SENT;
        String errorMessage = null;

        try {
            // mock send
            System.out.println("[notification-service] Sending " + eventType + " to " + recipient +
                    " for reservation " + reservationId + " traceId=" + traceId);
        } catch (Exception ex) {
            status = NotificationStatus.FAILED;
            errorMessage = ex.getMessage();
        }

        // guardar audit
        Notification n = new Notification();
        n.setReservationId(reservationId);
        n.setEventType(eventType);
        n.setRecipient(recipient);
        n.setStatus(status);
        n.setSentAt(Instant.now());
        n.setErrorMessage(errorMessage);

        notificationRepository.save(n);

        // marcar processed (idempotência)
        ProcessedEvent pe = new ProcessedEvent();
        pe.setEventType(eventType);
        pe.setProcessedAt(Instant.now());
        processedEventRepository.save(pe);

        // publicar restaurant.notified (apenas se SENT)
        if (status == NotificationStatus.SENT) {
            producer.publishRestaurantNotified(
                    eventType,
                    recipient,
                    "SENT"
            );
        } else {
            // opcional: publicar FAILED também (se o enunciado permitir)
            // producer.publishRestaurantNotified(reservationId, eventType, recipient, "FAILED", traceId);
        }
    }
}
