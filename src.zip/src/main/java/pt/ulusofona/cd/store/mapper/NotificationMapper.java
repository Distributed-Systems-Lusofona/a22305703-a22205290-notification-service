package pt.ulusofona.cd.store.mapper;

import pt.ulusofona.cd.store.events.EventEnvelope;
import pt.ulusofona.cd.store.events.ReservationEventPayload;
import pt.ulusofona.cd.store.model.Notification;
import pt.ulusofona.cd.store.model.NotificationStatus;
import pt.ulusofona.cd.store.dto.NotificationResponse;

import java.time.Instant;

public class NotificationMapper {

    private NotificationMapper() {}

    /**
     * Constrói um registo de auditoria (Notification) a partir de um evento de reserva.
     * - eventType vem do envelope (reservation.created / confirmed / cancelled)
     * - recipient: decide aqui (tipicamente customerEmail do payload; podes trocar para email do restaurante)
     * - status/sentAt/errorMessage vêm do resultado do "send"
     */
    public static Notification fromReservationEvent(
            EventEnvelope<ReservationEventPayload> envelope,
            String recipient,
            NotificationStatus status,
            Instant sentAt,
            String errorMessage
    ) {
        Notification n = new Notification();

        // Nota: no teu ReservationEventPayload o reservationId é Long (pela entity)
        // Se for String noutro lado, ajusta aqui.
        n.setReservationId(envelope.getPayload().getReservationId());
        n.setEventType(envelope.getEventType());
        n.setRecipient(recipient);

        n.setStatus(status);
        n.setSentAt(sentAt != null ? sentAt : Instant.now());
        n.setErrorMessage(errorMessage);

        return n;
    }

    public static NotificationResponse toResponse(Notification entity) {
        NotificationResponse r = new NotificationResponse();
        r.setId(entity.getId());
        r.setReservationId(entity.getReservationId());
        r.setEventType(entity.getEventType());
        r.setRecipient(entity.getRecipient());
        r.setStatus(entity.getStatus().name());
        r.setSentAt(entity.getSentAt());
        r.setErrorMessage(entity.getErrorMessage());
        return r;
    }
}
