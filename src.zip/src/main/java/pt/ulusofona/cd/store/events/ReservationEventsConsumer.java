package pt.ulusofona.cd.store.events;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pt.ulusofona.cd.store.model.Notification;
import pt.ulusofona.cd.store.model.NotificationStatus;
import pt.ulusofona.cd.store.model.ProcessedEvent;
import pt.ulusofona.cd.store.repository.NotificationRepository;
import pt.ulusofona.cd.store.repository.ProcessedEventRepository;

import java.time.Instant;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReservationEventsConsumer {

    private final NotificationRepository notificationRepository;
    private final ProcessedEventRepository processedEventRepository;
    private final RestaurantNotifiedProducer restaurantNotifiedProducer;

    @KafkaListener(
            topics = {
                    "${kafka.topics.reservation-created}",
                    "${kafka.topics.reservation-confirmed}",
                    "${kafka.topics.reservation-cancelled}"
            },
            groupId = "${kafka.consumer.group-id:notification-service-group}"
    )
    @Transactional
    public void onReservationEvent(
            EventEnvelope<ReservationEventPayload> envelope,
            Acknowledgment ack,
            @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset,
            @Header(value = KafkaHeaders.RECEIVED_KEY, required = false) String key
    ) {
        if (envelope == null || envelope.getPayload() == null) {
            log.warn("Skipping null envelope/payload (topic={}, partition={}, offset={})", topic, partition, offset);
            ack.acknowledge();
            return;
        }

        ReservationEventPayload payload = envelope.getPayload();
        String eventType = envelope.getEventType(); // reservation.created|confirmed|cancelled
        String traceId = (envelope.getTraceId() != null && !envelope.getTraceId().isBlank())
                ? envelope.getTraceId()
                : UUID.randomUUID().toString();

        // Chave de idempotência recomendada: (reservationId + eventType)
        String reservationId = String.valueOf(payload.getReservationId());
        String eventKey = reservationId + ":" + eventType;

        if (processedEventRepository.existsByEventKey(eventKey)) {
            log.info("Idempotent skip (already processed) eventKey={} (topic={}, partition={}, offset={})",
                    eventKey, topic, partition, offset);
            ack.acknowledge();
            return;
        }

        // “Adapter layer” simples: por agora, mandar notificação para o customerEmail (mock/log).
        // (Se quiseres notificar restaurante, tens de obter o email do restaurante noutro serviço/modelo,
        // mas o enunciado diz que este serviço não faz HTTP calls, então fica mock/log.)
        String recipient = payload.getCustomerEmail();

        Notification notification = new Notification();
        notification.setReservationId(payload.getReservationId());
        notification.setEventType(eventType);
        notification.setRecipient(recipient);

        try {
            // mock send (podes substituir por um adapter real no futuro)
            log.info("Sending notification (mock) eventType={} reservationId={} recipient={} traceId={}",
                    eventType, reservationId, recipient, traceId);

            notification.setStatus(NotificationStatus.SENT);
            notification.setSentAt(Instant.now());
            notification = notificationRepository.save(notification);

            ProcessedEvent pe = new ProcessedEvent();
            pe.setEventKey(eventKey);
            pe.setEventType(eventType);
            pe.setProcessedAt(Instant.now());
            processedEventRepository.save(pe);

            // Após persistir, publica restaurant.notified
            restaurantNotifiedProducer.publishRestaurantNotified(notification, eventType, traceId);

            // Commit offset só no fim (após persistência)
            ack.acknowledge();

        } catch (Exception ex) {
            // Em caso de falha: guarda FAILED e não faz ack (para reprocessar),
            // ou faz ack se preferires “dead-letter/retry topic”.
            log.error("Failed processing eventKey={} traceId={} (topic={}, partition={}, offset={})",
                    eventKey, traceId, topic, partition, offset, ex);

            notification.setStatus(NotificationStatus.FAILED);
            notification.setErrorMessage(ex.getMessage());
            notification.setSentAt(Instant.now());
            notificationRepository.save(notification);

            // Aqui tens 2 estratégias:
            // A) NÃO ack -> reprocessa (atenção: duplicados são evitados por processed_events, mas só se tiver sido gravado)
            // B) ack + DLQ (mais “clean” com @RetryableTopic)
            throw ex;
        }
    }
}
