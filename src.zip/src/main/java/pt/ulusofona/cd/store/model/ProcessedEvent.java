package pt.ulusofona.cd.store.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@Entity
@Table(
        name = "processed_events",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_processed_events_event_key", columnNames = "event_key")
        },
        indexes = {
                @Index(name = "idx_processed_events_event_type", columnList = "event_type")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProcessedEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // chave idempotente (ex: "<eventType>:<reservationId>")
    @NotBlank
    @Column(name = "event_key", nullable = false, length = 200)
    private String eventKey;

    @NotBlank
    @Column(name = "event_type", nullable = false, length = 60)
    private String eventType;

    @NotNull
    @Column(name = "processed_at", nullable = false)
    private Instant processedAt;

    @PrePersist
    protected void onCreate() {
        if (processedAt == null) processedAt = Instant.now();
    }
}
